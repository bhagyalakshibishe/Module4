package com.capg.bdd.UnitTesting;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScrollPageExample {
	public static void main(String args[]) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumDrivers\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.amazon.com/");
		//wait for 5 min
		Thread.sleep(2000);
		((JavascriptExecutor) driver).executeScript ("window.scrollBy(0,1045)");
		Thread.sleep(5000);
		driver.quit();
		
	}
	
}
