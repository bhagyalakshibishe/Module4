package com.capg.bdd.UnitTesting;

import static org.junit.Assert.*;

import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pop {
	@Test
	public void Popup() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumDrivers\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://10.219.34.76:7778/SeleniumWebApp/pop.html");
		Thread.sleep(2000);
		driver.findElement(By.id("a")).sendKeys("5");
		driver.findElement(By.id("b")).sendKeys("3");
		driver.findElement(By.name("add")).click();
		Alert alert = driver.switchTo().alert();
		Thread.sleep(2000);
		assertEquals("8",alert.getText());
		System.out.println(alert.getText());
		alert.accept();
		driver.close();
	}
}
