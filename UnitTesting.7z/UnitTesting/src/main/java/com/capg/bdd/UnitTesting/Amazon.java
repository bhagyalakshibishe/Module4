package com.capg.bdd.UnitTesting;

import static org.junit.Assert.*;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Amazon {
	@Test 
	public void AmazonSearch() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumDrivers\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.amazon.com/");
		driver.findElement(By.id("a-autoid-0-announce")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("createAccountSubmit")).click();
		Thread.sleep(2000);
		driver.getTitle().contains("Amazon Registration");
		assertTrue(driver.getTitle().contains("Amazon Registration"));
		driver.close();
	}
}
