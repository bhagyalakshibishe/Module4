package com.capg.unit;

import java.io.IOException;

import org.junit.Test;



public class Test1 {
	
		@Test
		public void testme() throws IOException {
			abcd();
			}
		
		public static void abcd() throws IOException //my unit
		{
			System.out.println("abcd invoked");
			throw new IOException();

		}
		
}

