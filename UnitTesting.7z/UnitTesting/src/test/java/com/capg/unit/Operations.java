package com.capg.unit;

public class Operations {
	public int add(int a, int b) {
		return a+b;
		
	}
	public int sub(int a, int b) {
		return a-b;
	}
}
