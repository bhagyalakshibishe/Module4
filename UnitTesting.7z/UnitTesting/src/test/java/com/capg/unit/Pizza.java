package com.capg.unit;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Pizza {
	public static void main(String...a) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumDrivers\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		//driver.get("https://www.myntra.com/");
		driver.findElement(By.name("Abhi"));
		driver.findElement(By.id("pizza"));
		driver.findElement(By.id("pizza1")); 
		driver.findElement(By.id("pizza2"));
		Select dropdown = new Select((WebElement) By.name("Chicken")); 
		
//		radioBtn.click();
		driver.findElement(By.name("q")).sendKeys("bhagya");
		driver.findElement(By.name("btnk")).submit();
		
		
		//System.out.println(driver.findElements(By.tagName("img")).size());
		driver.close();
		
		
}
}
