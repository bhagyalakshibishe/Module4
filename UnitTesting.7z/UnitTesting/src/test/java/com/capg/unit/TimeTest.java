package com.capg.unit;

import org.junit.Test;

public class TimeTest {
	
	@Test(timeout=100) 
	public void display() {
//		try {
//			//Thread.sleep(10000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
	}
}
