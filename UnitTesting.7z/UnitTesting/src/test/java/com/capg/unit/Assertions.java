package com.capg.unit;

import static org.junit.Assert.*;

import org.junit.Test;

public class Assertions {
	String string5=null;
	String string1="hello";
	String string2="hello";
	int variable1  =  1;
	int variable2 = 2;
	int[] arithmaticArray1 = {1,2,3,4};
	int[] arithmaticArray2 = {1,2,3,4};
	
	//Assert statements
	@Test
	public void display() {
	assertEquals(string1, string2);
	assertSame(string1, string2);
	assertNotSame(string1, string2);
	assertNotNull(string1);
	assertNull(string1);
	assertTrue(variable1<variable2);
	assertArrayEquals(arithmaticArray1, arithmaticArray2);
	}
}
