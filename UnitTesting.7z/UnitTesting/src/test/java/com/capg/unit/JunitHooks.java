package com.capg.unit;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class JunitHooks {
	
	@BeforeClass 
	public static void bclass() {
		System.out.println(".....");
	}
	
	
	@Before
	public  void booting() {
		System.out.println("invoked before");
	}
	
	public static int add(int a, int b) {
		return a+b;	
	}
	
	// @Test
	@Ignore
	public void display() {
		System.out.println("Display this....");
		
	}
	
	
	
	@Test 
	public void random() {
		System.out.println("Its other testcase");
	}
	
	@After
	public void  after(){
		System.out.println("*****");
	}
	
}
