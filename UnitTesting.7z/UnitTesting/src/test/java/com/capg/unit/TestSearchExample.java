package com.capg.unit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestSearchExample {
	public static void main(String...a) {
			
			System.setProperty("webdriver.chrome.driver", "C:\\SeleniumDrivers\\chromedriver_win32\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.get("https://www.google.com/");
			driver.findElement(By.name("q")).sendKeys("bhagya");
			driver.findElement(By.name("btnk")).submit();
			System.out.println("Title name is " + driver.getTitle());			
	}
}
