package com.capg.unit;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestClient {
	
	@Test
	public void tetFindMax() {
		assertEquals (5,new Operations().add(2,2));
		assertEquals(-1,new Operations().sub(1,2));
	}
	
	@Test
	public void invoke() {
		System.out.println("............");
	}
}
