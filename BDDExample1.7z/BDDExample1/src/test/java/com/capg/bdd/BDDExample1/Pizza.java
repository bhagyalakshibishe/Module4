package com.capg.bdd.BDDExample1;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Pizza {
	@Given("^the successful order done by the customer$")
	public void the_successful_order_done_by_the_customer() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^the customer selects the Name$")
	public void the_customer_selects_the_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^selects pizza toppings, pizza sauce$")
	public void selects_pizza_toppings_pizza_sauce() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^clicks on \"([^\"]*)\"$")
	public void clicks_on(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Pizza is delivered on successful order$")
	public void pizza_is_delivered_on_successful_order() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^the unsuccessful order made by the customer$")
	public void the_unsuccessful_order_made_by_the_customer() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^the customer selects the name$")
	public void the_customer_selects_the_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^chooses any of the pizza toppings but none of the pizza sauce$")
	public void chooses_any_of_the_pizza_toppings_but_none_of_the_pizza_sauce() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the pizza is not delivered on unsuccessful order$")
	public void the_pizza_is_not_delivered_on_unsuccessful_order() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^chooses any of the pizza sauce but none of the pizza toppings$")
	public void chooses_any_of_the_pizza_sauce_but_none_of_the_pizza_toppings() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
