package com.capg.bdd.BDDExample1;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Google {
	@Given("^page will not be navigated$")
	public void page_will_not_be_navigated() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^i enter nothing in google search$")
	public void i_enter_nothing_in_google_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^it should remain in same page$")
	public void it_should_remain_in_same_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^i enter space bar in google search$")
	public void i_enter_space_bar_in_google_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^Page is navigated to the particular searched url$")
	public void page_is_navigated_to_the_particular_searched_url() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^i enter some url$")
	public void i_enter_some_url() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the page gets navigated to that url\\.$")
	public void the_page_gets_navigated_to_that_url() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
