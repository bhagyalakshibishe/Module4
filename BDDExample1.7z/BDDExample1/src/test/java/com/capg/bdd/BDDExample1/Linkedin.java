package com.capg.bdd.BDDExample1;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Linkedin {
	
	@Given("^Failure in account creation$")
	public void failure_in_account_creation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I try to create a new account with the existing email$")
	public void i_try_to_create_a_new_account_with_the_existing_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^A failure message should display as \"([^\"]*)\"$")
	public void a_failure_message_should_display_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^Success in account creation$")
	public void success_in_account_creation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I try to create a new account with the new email$")
	public void i_try_to_create_a_new_account_with_the_new_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^A Success message should display as \"([^\"]*)\"$")
	public void a_Success_message_should_display_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
